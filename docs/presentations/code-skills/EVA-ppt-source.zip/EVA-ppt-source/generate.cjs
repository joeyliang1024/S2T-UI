const fs=require('fs');
const PptxGenJS=require('pptxgenjs');
const html2pptx=require('/Users/liangzhiquan/.codex/skills/.system/pptx/scripts/html2pptx.js');
const dir=__dirname;
const old=JSON.parse(fs.readFileSync(dir+'/content.json','utf8'));
const p=new PptxGenJS();p.defineLayout({name:'EVA',width:13.333333,height:7.5});p.layout='EVA';p.title='AI coding 的 review 工具';p.theme={headFontFace:'Arial',bodyFontFace:'Arial',lang:'zh-TW'};
const txt=(t,size=22,color='#F5F3ED',bold=false)=>`<p style="font-size:${size}pt;color:${color};font-weight:${bold?700:400};margin:0;line-height:1.25">${t}</p>`;
const block=(x,y,w,h,content,extra='')=>`<div style="position:absolute;left:${x}pt;top:${y}pt;width:${w}pt;height:${h}pt;box-sizing:border-box;${extra}">${content}</div>`;
const mono=(t,size=13,color='#B4ACBF')=>`<p style="font-family:Courier New;font-size:${size}pt;color:${color};margin:0;line-height:1.25">${t}</p>`;
const dots=()=>`<div style="display:flex;gap:6pt"><div style="width:7pt;height:7pt;border-radius:50%;background:#E84332"></div><div style="width:7pt;height:7pt;border-radius:50%;background:#F5F3ED"></div><div style="width:7pt;height:7pt;border-radius:50%;background:#47DF39"></div><div style="width:7pt;height:7pt;border-radius:50%;background:#A27BCD"></div></div>`;
const card=(x,y,w,h,label,body,color='#A27BCD')=>block(x,y,w,h,
`<div style="height:18pt;display:flex;gap:12pt;align-items:center">${dots()}${mono('skill://'+label.toLowerCase().replaceAll(' ','_'),9)}</div><div style="margin-top:15pt">${txt(label,24,color,true)}</div><div style="margin-top:17pt">${body}</div>`,
`padding:20pt;background:#201A2C;border:1.1pt solid ${color};border-radius:12pt;box-shadow:0 7pt 14pt rgba(0,0,0,0.22)`);
function base(i,title,subtitle,body){return `<!doctype html><html><head><meta charset="utf-8"><style>body{position:relative;width:960pt;height:540pt;margin:0;display:flex;background:#100F14;font-family:Arial,sans-serif}p{box-sizing:border-box}</style></head><body>${['#E84332','#F5F3ED','#47DF39','#A27BCD'].map((c,k)=>block(k*240,0,240,4,'','background:'+c)).join('')}${block(44,35,850,60,txt(title,32,'#F5F3ED',true))}${block(44,101,850,40,txt(subtitle,16,'#B4ACBF'))}${body}${block(44,485,500,25,mono('> code_skills --session 15min',10,'#8F849F'))}${block(863,482,54,26,txt(String(i).padStart(2,'0'),15,'#47DF39',true))}</body></html>`;}
let slides=[];
slides.push(base(1,'AI coding 的 review 工具','讓 review 跟上開發速度',card(44,177,422,240,'code-review',txt('check / review / audit',24)+`<div style="margin-top:30pt">${txt('Subagent 分工<br>Code-graph 與紀錄保存',20,'#BFB6CE')}</div>`)+card(490,177,426,240,'code-scan',txt('用途與兩個介紹重點',24)+`<div style="margin-top:30pt">${txt('實際案例<br>第一次使用方式',20,'#BFB6CE')}</div>`,'#47DF39')));
slides.push(base(2,'AI coding 加速了，review 也要跟上','工具的出發點',card(44,177,422,244,'寫得更快',txt('AI 協助產出程式碼',27)+`<div style="margin-top:24pt">${txt('改動仍需要確認',22,'#BFB6CE')}</div>`)+card(490,177,426,244,'共同的 review 標準',txt('把公司的檢查規範<br>整理成可執行的 skill',25)+`<div style="margin-top:24pt">${txt('讓 AI 協助執行 review',20,'#BFB6CE')}</div>`,'#47DF39')));
slides.push(base(3,'兩個 skill 的使用入口','用實際案例介紹各自的用途',card(44,177,422,244,'code-review',txt('三種模式',25)+`<div style="margin-top:22pt">${txt('check / review / audit<br>多個 subagent 與 code-graph<br>保存檢查紀錄',19,'#BFB6CE')}</div>`)+card(490,177,426,244,'code-scan',txt('兩個介紹重點',25)+`<div style="margin-top:22pt">${txt('［補上用途與使用情境］<br>［補上兩個功能或模式］<br>展示實際執行結果',19,'#BFB6CE')}</div>`,'#47DF39')));
slides.push(base(4,'code-review 的三種模式','依照實際需求選擇模式', ['check','review','audit'].map((n,i)=>card(44+i*296,177,280,256,n,txt('使用情境',18,'#BFB6CE')+`<div style="margin-top:14pt">${txt('［填入典型情境］',21)}</div><div style="margin-top:19pt">${txt('檢查範圍',18,'#BFB6CE')}</div><div style="margin-top:14pt">${txt('［填入範圍］',21)}</div>`,['#F5F3ED','#47DF39','#E84332'][i])).join('')));
slides.push(base(5,'code-review 的檢查方式','Subagent、程式關係資訊與檢查紀錄',card(44,177,280,256,'SUBAGENTS',txt('多個 agent<br>分工檢查',26)+`<div style="margin-top:19pt">${txt('［補上實際分工］',18,'#BFB6CE')}</div>`)+card(340,177,280,256,'CODE-GRAPH',txt('程式關係資訊<br>輔助 review',25)+`<div style="margin-top:19pt">${txt('用案例展示關聯線索',18,'#BFB6CE')}</div>`,'#47DF39')+card(636,177,280,256,'RECORDS',txt('保存<br>檢查紀錄',26)+`<div style="margin-top:19pt">${txt('方便回看與追蹤',18,'#BFB6CE')}</div>`,'#F5F3ED')));
function demo(i,title,questions,accent){return base(i,title,'60 秒精華 demo，搭配一個關鍵結果',card(44,177,552,260,'DEMO / 60 SEC',`<div style="margin-top:38pt">${txt('［放入影片或結果截圖］',26)}</div>`,accent)+card(616,177,300,260,'案例重點',questions.map((q,j)=>`<div style="margin-top:${j?21:0}pt">${txt(q,20,j===2?accent:'#F5F3ED')}</div>`).join(''),accent));}
slides.push(demo(6,'code-review 實際案例',['這次改了什麼？','找到什麼值得修的問題？','分工與 graph 如何幫忙？'],'#A27BCD'));
slides.push(base(7,'code-scan 的用途與兩個重點','［一句話說明 code-scan 的用途］',card(44,177,422,256,'01 / ［第一個重點］',txt('［填入功能或模式名稱］',23)+`<div style="margin-top:19pt">${txt('什麼時候用？<br>會得到什麼結果？',21,'#BFB6CE')}</div>`,'#47DF39')+card(490,177,426,256,'02 / ［第二個重點］',txt('［填入功能或模式名稱］',23)+`<div style="margin-top:19pt">${txt('什麼時候用？<br>會得到什麼結果？',21,'#BFB6CE')}</div>`,'#A27BCD')));
slides.push(demo(8,'code-scan 實際案例',['為什麼執行這次 scan？','最值得注意的結果？','接下來可以做什麼？'],'#47DF39'));
slides.push(base(9,'下一次開發，就能開始試用','選一個適合的情境，看看工具能幫上什麼忙',card(44,177,422,256,'取得工具',txt('［工具與文件連結］',26)+`<div style="margin-top:25pt">${txt('［安裝或啟用方式］<br>［回饋管道］',21,'#BFB6CE')}</div>`,'#47DF39')+card(490,177,426,256,'第一次執行',txt('［完整指令］',28)+`<div style="margin-top:25pt">${txt('完整 demo 放在使用文件<br>歡迎回饋實際使用結果',20,'#BFB6CE')}</div>`)));
function special(kind,name,n,desc,cmd,accent){
 const terminal=block(530,177,385,247,
 `<div style="height:22pt;display:flex;gap:16pt;align-items:center">${dots()}${mono('session / local',11)}</div><div style="margin-top:32pt">${mono('&gt; '+cmd,17,'#47DF39')}</div><div style="margin-top:20pt">${mono('section: '+name,14,'#F5F3ED')}</div><div style="margin-top:16pt">${mono('ready for presentation',13,'#A27BCD')}</div><div style="margin-top:27pt">${mono('&gt; _',22,'#47DF39')}</div>`,
 'padding:24pt;background:#19161F;border:1.2pt solid '+accent+';border-radius:12pt');
 const graphic=block(772,39,160,95,txt(n,74,'#443256',true));
 return base(0,kind,'AI CODING / TEAM REVIEW',
 block(44,201,480,83,txt(name,kind==='CODE SKILLS'?39:43,'#F5F3ED',true))+
 block(46,316,438,93,txt(desc,25,'#A27BCD'))+terminal+graphic+
 block(44,454,360,3,'','background:'+accent));
}
const cover=special('CODE SKILLS','Review + Scan','00','讓 review 跟上開發速度','skills --start','#E84332');
const review=special('SECTION 01','code-review','01','多個 subagent 與 code-graph<br>協助完成檢查','loading code-review','#A27BCD');
const scan=special('SECTION 02','code-scan','02','用途、兩個介紹重點<br>以及實際案例','loading code-scan','#47DF39');
let deck=[cover,slides[1],slides[2],review,slides[3],slides[4],slides[5],scan,slides[6],slides[7],slides[8]];
let notes=[old[0].notes,old[1].notes,old[2].notes,'建議時間：10 秒。進入 code-review。',old[3].notes,old[4].notes,old[5].notes,'建議時間：10 秒。切換到 code-scan。',old[6].notes,old[7].notes,old[8].notes];
(async()=>{for(let i=0;i<deck.length;i++){
 let html=deck[i].replace(/<p([^>]*font-size:15pt[^>]*)>\d{2}<\/p>/,`<p$1>${String(i+1).padStart(2,'0')}</p>`);
 let f=dir+`/terminal-${i+1}.html`;fs.writeFileSync(f,html);
 let {slide}=await html2pptx(f,p,{tmpDir:dir});slide.addNotes(notes[i]);
}await p.writeFile({fileName:dir+'/terminal-candidate.pptx'});console.log('Created 11 slides');})().catch(e=>{console.error(e);process.exit(1)});
