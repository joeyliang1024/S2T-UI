from pathlib import Path
import re
import zipfile

root = Path(__file__).resolve().parent
source = root / 'terminal-candidate.pptx'
output = root / 'EVA-code-skills-terminal.pptx'
with zipfile.ZipFile(source) as archive:
    parts = {name: archive.read(name) for name in archive.namelist()}
xml = parts['[Content_Types].xml'].decode('utf-8')
xml = re.sub(
    r'<Override\b[^>]*PartName="([^"]+)"[^>]*/>',
    lambda match: match.group(0) if match.group(1).lstrip('/') in parts else '',
    xml,
)
parts['[Content_Types].xml'] = xml.encode('utf-8')
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in parts.items():
        archive.writestr(name, data)
print(output)
