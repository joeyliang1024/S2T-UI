# EVA 投影片原始碼

`generate.cjs` 是最終 11 張投影片的 JavaScript 生成程式。
`terminal-1.html` 至 `terminal-11.html` 是各頁 HTML 版面。
`content.json` 提供原版講者備註；投影片文字與樣式目前直接定義在 generate.cjs。

## 製作方式

使用 PptxGenJS 與指定 pptx skill 的 html2pptx.js。
字型為 Arial、Courier New；中文由系統字型補足。
紅 #E84332、暖白 #F5F3ED、綠 #47DF39、紫 #A27BCD，深色背景 #100F14。

## 在目前電腦執行

在此資料夾開啟終端機：

```sh
NODE_PATH=/Users/liangzhiquan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules \
/Users/liangzhiquan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node generate.cjs
```

需要本機 Google Chrome。程式會呼叫 Playwright 啟動無頭瀏覽器，並輸出 terminal-candidate.pptx。

生成後清理 PptxGenJS 多餘的 Content Types 宣告：

```sh
/Users/liangzhiquan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 clean_package.py
```

清理後輸出 EVA-code-skills-terminal.pptx。
這個步驟只修正套件宣告，不改投影片內容。

## 改內容

修改 generate.cjs 內的 slides、card、demo 與 special。
改 HTML 檔本身不會影響 generate.cjs 的輸出，因為執行時會重新產生 HTML。

## 搬到其他電腦

安裝 Node.js、pptxgenjs、playwright、sharp 及 Chrome。
修改 generate.cjs 中 html2pptx.js 的絕對路徑，指向當地 pptx skill。
此包未重複收錄 skill 與第三方套件。
